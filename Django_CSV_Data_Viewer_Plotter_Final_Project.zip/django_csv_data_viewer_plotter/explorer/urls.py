from django.urls import path
from . import views

urlpatterns = [
    path("", views.home, name="home"),
    path("analyse/", views.analyse_csv, name="analyse_csv"),
    path("plot/", views.generate_plot, name="generate_plot"),
]
