# Django CSV Data Viewer & Plotter

A completed reference solution for the **Final Project — CSV Data Viewer & Plotter**.

## Features

- Upload a CSV file
- Display filename and dataset dimensions
- Show column names
- Preview the first 20 rows
- Generate Pandas descriptive statistics
- Show missing-value counts
- Select numeric X and Y columns
- Create scatter, line and bar plots
- Bootstrap interface

## Run the project

Create and activate a virtual environment:

```bash
python -m venv venv
```

Linux/macOS:

```bash
source venv/bin/activate
```

Windows:

```bash
venv\Scripts\activate
```

Install dependencies:

```bash
pip install -r requirements.txt
```

Run migrations:

```bash
python manage.py migrate
```

Start Django:

```bash
python manage.py runserver
```

Open:

```text
http://127.0.0.1:8000/
```

A sample dataset is included at:

```text
data/students.csv
```

## Learning note

This project intentionally keeps the implementation straightforward so it can be compared directly with the tutorial lessons. Uploaded CSV data is stored temporarily in the Django session for the plotting step. This is suitable for a small training project, but a production application would normally use more robust storage and upload limits.
