import base64
import io

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

from django.shortcuts import redirect, render


def home(request):
    return render(request, "explorer/upload.html")


def analyse_csv(request):
    if request.method != "POST":
        return redirect("home")

    file = request.FILES.get("file")

    if not file:
        return render(
            request,
            "explorer/upload.html",
            {"error": "Please select a CSV file."},
        )

    if not file.name.lower().endswith(".csv"):
        return render(
            request,
            "explorer/upload.html",
            {"error": "Please upload a .csv file."},
        )

    try:
        raw = file.read()
        df = pd.read_csv(io.BytesIO(raw))
    except Exception as exc:
        return render(
            request,
            "explorer/upload.html",
            {"error": f"Could not read the CSV file: {exc}"},
        )

    # Store the uploaded CSV in the session so the plot page can reuse it.
    request.session["csv_data"] = base64.b64encode(raw).decode("ascii")
    request.session["csv_filename"] = file.name

    numeric_columns = df.select_dtypes(include="number").columns.tolist()

    context = {
        "filename": file.name,
        "rows": df.shape[0],
        "column_count": df.shape[1],
        "columns": df.columns.tolist(),
        "numeric_columns": numeric_columns,
        "table": df.head(20).to_html(
            index=False,
            classes="table table-striped table-hover align-middle",
            border=0,
        ),
        "summary": (
            df.describe().to_html(
                classes="table table-striped table-hover align-middle",
                border=0,
            )
            if numeric_columns
            else None
        ),
        "missing_values": df.isnull().sum().to_dict(),
    }

    return render(request, "explorer/results.html", context)


def generate_plot(request):
    if request.method != "POST":
        return redirect("home")

    encoded_csv = request.session.get("csv_data")

    if not encoded_csv:
        return render(
            request,
            "explorer/upload.html",
            {"error": "Please upload a dataset first."},
        )

    raw = base64.b64decode(encoded_csv)
    df = pd.read_csv(io.BytesIO(raw))

    x_column = request.POST.get("x_column")
    y_column = request.POST.get("y_column")
    plot_type = request.POST.get("plot_type", "scatter")

    numeric_columns = df.select_dtypes(include="number").columns.tolist()

    if x_column not in df.columns or y_column not in df.columns:
        return redirect("home")

    if x_column not in numeric_columns or y_column not in numeric_columns:
        return render(
            request,
            "explorer/plot.html",
            {
                "error": "Please choose numeric columns for this example.",
                "numeric_columns": numeric_columns,
            },
        )

    fig, ax = plt.subplots(figsize=(8, 5))

    if plot_type == "line":
        ax.plot(df[x_column], df[y_column])
    elif plot_type == "bar":
        ax.bar(df[x_column], df[y_column])
    else:
        ax.scatter(df[x_column], df[y_column])

    ax.set_xlabel(x_column)
    ax.set_ylabel(y_column)
    ax.set_title(f"{y_column} vs {x_column}")
    fig.tight_layout()

    image_buffer = io.BytesIO()
    fig.savefig(image_buffer, format="png")
    plt.close(fig)
    image_buffer.seek(0)

    plot_image = base64.b64encode(image_buffer.read()).decode("ascii")

    return render(
        request,
        "explorer/plot.html",
        {
            "filename": request.session.get("csv_filename"),
            "x_column": x_column,
            "y_column": y_column,
            "plot_type": plot_type,
            "plot_image": plot_image,
        },
    )
